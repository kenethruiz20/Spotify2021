import React from "react";

import "./Footer.css";

export default function Footer() {
  return (
    <div>
      <h1>Test</h1>
    </div>
  );
}
