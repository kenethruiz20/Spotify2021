export const propic = [
  "https://occ-0-1068-92.1.nflxso.net/dnm/api/v6/K6hjPJd6cR6FpVELC5Pd6ovHRSk/AAAAFH0VbIGycnpOMaFT5ER1erOVKsxpCLYnZF0-sxIK15G0mY7z7RnNlEEiRFGOOBCJcyB2CEibnXtHsXwNqmcCGg-XlQ.png?r=9fe",
  "https://occ-0-1068-92.1.nflxso.net/dnm/api/v6/K6hjPJd6cR6FpVELC5Pd6ovHRSk/AAAAFOcTRx14xrh4-lRIEYsx04g5VwqS9RVkgDnvSjECxpGz6Gc47D1HU4XTpr784OnX-LZTDLx3IVCPumrp9RTE_vBPoQ.png?r=318",
  "https://occ-0-1068-92.1.nflxso.net/dnm/api/v6/K6hjPJd6cR6FpVELC5Pd6ovHRSk/AAAAFAjYfmW-pMf4eJv6L1h_-qrS69TJFXSqTTmir68XAraXSTUNv5jCnBmO9oenrpQyPKPk1sHlD2U3OxeW6rv8vqsYdg.png?r=c71",
  "https://occ-0-1068-92.1.nflxso.net/dnm/api/v6/K6hjPJd6cR6FpVELC5Pd6ovHRSk/AAAAFKK6v8Xsq0zuWKuGVn4zdjdzEj6PCR2PUlnsQXMNC1ac1itCk9fvQODW3oIWuCo_JANsujRABfCpLhjs7wr76mM4Jg.png?r=06d",
  "https://occ-0-1068-92.1.nflxso.net/dnm/api/v6/K6hjPJd6cR6FpVELC5Pd6ovHRSk/AAAAFI1ivM5hvHP4djh3YwUOmFrW7QXlGQu8k4K2jlLG1ZT_gcqtNa9At2Q06sdCwqAE_NYruKKc6oTb-YbazGCHNkAcow.png?r=fdd",
  "https://occ-0-1068-92.1.nflxso.net/dnm/api/v6/K6hjPJd6cR6FpVELC5Pd6ovHRSk/AAAAFODe-79HMte1GvxsxPzvEhS4oamceVNh3isrrNF3kcraRbsL9uOcrH0MyKtlmWkLJyKJIxId66coocNnpINTOKpTcQ.png?r=f08",
];

export const chicken =
  "https://occ-0-1068-92.1.nflxso.net/dnm/api/v6/K6hjPJd6cR6FpVELC5Pd6ovHRSk/AAAAFH0VbIGycnpOMaFT5ER1erOVKsxpCLYnZF0-sxIK15G0mY7z7RnNlEEiRFGOOBCJcyB2CEibnXtHsXwNqmcCGg-XlQ.png?r=9fe";
